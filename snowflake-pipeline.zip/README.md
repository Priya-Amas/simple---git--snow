# Snowflake Pipeline

This is a simple Snowflake pipeline with GitHub Actions CI/CD.

## SQL Scripts

Each script in the `sql/` folder sets up a component of the pipeline:
- File format
- Stage
- Table
- Pipe
- Stream
- Procedure
- Task

## GitHub Actions

A deploy workflow runs SnowSQL to execute each script on push to main.

## Secrets Required

Configure the following secrets in your GitHub repository:
- SNOWSQL_ACCOUNT
- SNOWSQL_USER
- SNOWSQL_PASSWORD
- SNOWSQL_ROLE
- SNOWSQL_WAREHOUSE
- SNOWSQL_DATABASE
- SNOWSQL_SCHEMA
